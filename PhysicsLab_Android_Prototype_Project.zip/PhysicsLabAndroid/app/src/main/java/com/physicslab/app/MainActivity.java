package com.physicslab.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/**
 * Physics Lab - Android proof of concept.
 * Authentication and data persistence are local-only demo implementations.
 * Production use requires real identity verification and server-side admin authorization.
 */
public class MainActivity extends Activity {
    private static final String ADMIN_EMAIL = "tamannakamrunnahar1235@gmail.com";
    private static final String PREFS = "physics_lab_demo";
    private static final int PICK_PDF = 4021;
    private static final int NAVY = Color.rgb(16, 24, 43);
    private static final int NAVY2 = Color.rgb(24, 36, 60);
    private static final int PANEL = Color.rgb(31, 45, 72);
    private static final int TEAL = Color.rgb(87, 224, 192);
    private static final int TEXT = Color.rgb(242, 246, 255);
    private static final int MUTED = Color.rgb(169, 184, 207);
    private static final int PURPLE = Color.rgb(159, 136, 255);

    private SharedPreferences prefs;
    private String email = "";
    private boolean isAdmin = false;
    private boolean lessonScreenOpen = false;
    private boolean playing = false;
    private boolean resumeAfterDiagram = false;
    private boolean diagramAlreadyShown = false;
    private int typedIndex = 0;
    private int savedScrollY = 0;
    private int cueIndex = 0;
    private String lessonTitle;
    private String lessonNotes;
    private String importedPdfName = "No PDF selected yet";

    private final Handler handler = new Handler();
    private Runnable typingRunnable;
    private LinearLayout lessonRoot;
    private ScrollView notesScroll;
    private TextView notesText;
    private TextView playbackStatus;
    private Button playButton;
    private EditText adminTitleInput;
    private EditText adminNotesInput;
    private EditText loginEmailInput;
    private EditText loginPasswordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        lessonTitle = prefs.getString("lesson_title", "Magnetic field around a wire");
        lessonNotes = prefs.getString("lesson_notes", defaultLessonNotes());
        importedPdfName = prefs.getString("pdf_name", "No PDF selected yet");
        email = prefs.getString("email", "");
        isAdmin = ADMIN_EMAIL.equalsIgnoreCase(email);
        if (email.isEmpty()) showLogin(); else showDashboard();
    }

    private String defaultLessonNotes() {
        return "MAGNETIC EFFECT OF ELECTRIC CURRENT\n\n" +
                "Learning goal\nUnderstand how electric current produces a magnetic field around a conductor.\n\n" +
                "1. The magnetic effect of current\nWhen electric current passes through a conducting wire, a magnetic field is produced around the wire. A compass placed nearby deflects, showing that the field is present.\n\n" +
                "2. Direction of the field\nThe direction of the magnetic field depends on the direction of current. The right-hand thumb rule helps us determine this direction.\n\n" +
                "3. Important observation\nThe field lines form concentric circles around a straight current-carrying conductor. Their spacing represents the relative strength of the field.\n\n" +
                "4. Remember\nReverse the current and the magnetic field direction also reverses. The field becomes weaker as you move farther from the wire.\n\n" +
                "Quick check\nWhat happens to the direction of the magnetic field when the current is reversed? Explain using the right-hand thumb rule.\n\n" +
                "Summary\nElectric current produces a magnetic field. For a straight wire, the magnetic field lines are concentric circles around the conductor.";
    }

    private void showLogin() {
        lessonScreenOpen = false;
        playing = false;
        handler.removeCallbacksAndMessages(null);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = pageColumn();
        page.setPadding(dp(24), dp(30), dp(24), dp(24));
        scroll.addView(page);
        page.addView(spacer(24));
        TextView logo = text("PHYSICS LAB", 13, TEAL, true);
        logo.setLetterSpacing(0.18f);
        page.addView(logo);
        page.addView(spacer(12));
        page.addView(text("Physics, made\nvisible.", 34, TEXT, true));
        page.addView(spacer(12));
        page.addView(text("Lecturer-style lessons with animated diagrams, study notes and assignments.", 16, MUTED, false));
        page.addView(spacer(28));
        LinearLayout card = cardColumn();
        card.setPadding(dp(20), dp(22), dp(20), dp(22));
        page.addView(card, matchWrap());
        card.addView(text("Welcome back", 22, TEXT, true));
        card.addView(spacer(6));
        card.addView(text("Sign in to enter your classroom.", 14, MUTED, false));
        card.addView(spacer(20));
        loginEmailInput = editField("Email address", false);
        loginEmailInput.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS );
        if (!email.isEmpty()) loginEmailInput.setText(email);
        card.addView(loginEmailInput, matchWrap());
        card.addView(spacer(12));
        loginPasswordInput = editField("Password (6+ characters)", true);
        loginPasswordInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        card.addView(loginPasswordInput, matchWrap());
        card.addView(spacer(18));
        Button login = primaryButton("Sign in");
        card.addView(login, matchWrap());
        login.setOnClickListener(v -> {
            String candidate = loginEmailInput.getText().toString().trim().toLowerCase(Locale.ROOT);
            String password = loginPasswordInput.getText().toString();
            if (!android.util.Patterns.EMAIL_ADDRESS.matcher(candidate).matches()) {
                loginEmailInput.setError("Enter a valid email address"); return;
            }
            if (password.length() < 6) {
                loginPasswordInput.setError("Use at least 6 characters"); return;
            }
            email = candidate;
            isAdmin = ADMIN_EMAIL.equalsIgnoreCase(email);
            prefs.edit().putString("email", email).apply();
            showDashboard();
            Toast.makeText(this, "Demo sign-in only — no account was verified online.", Toast.LENGTH_LONG).show();
        });
        page.addView(spacer(16));
        TextView notice = text("PROTOTYPE MODE  ·  Local demo sign-in only. Do not use real passwords. Production requires verified sign-in and server-secured admin access.", 12, MUTED, false);
        page.addView(notice);
        setContentView(scroll);
    }

    private void showDashboard() {
        lessonScreenOpen = false;
        playing = false;
        handler.removeCallbacksAndMessages(null);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = pageColumn();
        page.setPadding(dp(20), dp(18), dp(20), dp(26));
        scroll.addView(page);
        page.addView(topBar(isAdmin ? "LECTURER WORKSPACE" : "YOUR CLASSROOM"));
        page.addView(spacer(22));
        page.addView(text(isAdmin ? "Build a better\nphysics lesson." : "Keep your curiosity\nin motion.", 30, TEXT, true));
        page.addView(spacer(10));
        page.addView(text(isAdmin ? "Prepare, review and publish lesson material." : "Pick up where you left off, one concept at a time.", 15, MUTED, false));
        page.addView(spacer(20));

        LinearLayout hero = cardColumn();
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        page.addView(hero, matchWrap());
        hero.addView(text("FEATURED LESSON", 12, TEAL, true));
        hero.addView(spacer(8));
        hero.addView(text(lessonTitle, 21, TEXT, true));
        hero.addView(spacer(7));
        hero.addView(text("Magnetism  ·  8 min  ·  Animated demonstration", 13, MUTED, false));
        hero.addView(spacer(16));
        Button openLesson = primaryButton(isAdmin ? "Preview lesson  →" : "Continue lesson  →");
        hero.addView(openLesson, matchWrap());
        openLesson.setOnClickListener(v -> showLesson());

        page.addView(spacer(16));
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(statCard(isAdmin ? "CONTENT" : "PROGRESS", isAdmin ? "01" : "25%", isAdmin ? "lesson draft" : "lesson started"), new LinearLayout.LayoutParams(0, dp(100), 1));
        View statGap = spacer(10); stats.addView(statGap, new LinearLayout.LayoutParams(dp(10), 1));
        stats.addView(statCard(isAdmin ? "STUDENTS" : "TASKS", isAdmin ? "—" : "02", isAdmin ? "backend not connected" : "to review"), new LinearLayout.LayoutParams(0, dp(100), 1));
        page.addView(stats);
        page.addView(spacer(22));

        if (isAdmin) {
            page.addView(sectionHeading("LESSON MANAGEMENT", "LOCAL DRAFT"));
            page.addView(spacer(10));
            Button edit = secondaryButton("Edit lesson and lesson plan");
            page.addView(edit, matchWrap()); edit.setOnClickListener(v -> showAdminEditor());
            page.addView(spacer(10));
            Button upload = secondaryButton("Choose a physics PDF");
            page.addView(upload, matchWrap()); upload.setOnClickListener(v -> pickPdf());
            page.addView(spacer(8));
            page.addView(text(importedPdfName, 12, MUTED, false));
            page.addView(spacer(10));
            Button students = secondaryButton("Student submissions (demo)");
            page.addView(students, matchWrap()); students.setOnClickListener(v -> showSubmissions());
        } else {
            page.addView(sectionHeading("YOUR LEARNING", "THIS WEEK"));
            page.addView(spacer(10));
            page.addView(infoRow("01", "Magnetic effect of current", "Lecture notes + animated diagram", () -> showLesson()));
            page.addView(spacer(8));
            page.addView(infoRow("02", "Assignment: field direction", "Practice question · Not submitted", () -> showAssignment()));
        }
        page.addView(spacer(22));
        page.addView(text("Signed in as " + email, 12, MUTED, false));
        page.addView(spacer(10));
        Button signOut = secondaryButton("Sign out");
        page.addView(signOut, matchWrap());
        signOut.setOnClickListener(v -> { email = ""; isAdmin = false; prefs.edit().remove("email").apply(); showLogin(); });
        setContentView(scroll);
    }

    private void showLesson() {
        handler.removeCallbacksAndMessages(null);
        playing = false;
        lessonScreenOpen = true;
        diagramAlreadyShown = false;
        typedIndex = 0;
        cueIndex = Math.max(80, lessonNotes.length() / 2);
        lessonRoot = new LinearLayout(this);
        lessonRoot.setOrientation(LinearLayout.VERTICAL);
        lessonRoot.setBackgroundColor(NAVY);
        lessonRoot.setPadding(dp(16), dp(12), dp(16), dp(12));
        lessonRoot.addView(topBar("LESSON EXPERIENCE"));
        lessonRoot.addView(spacer(12));
        LinearLayout titleBlock = cardColumn();
        titleBlock.setPadding(dp(14), dp(14), dp(14), dp(14));
        titleBlock.addView(text("TODAY'S CONCEPT", 11, TEAL, true));
        titleBlock.addView(spacer(5));
        titleBlock.addView(text(lessonTitle, 20, TEXT, true));
        lessonRoot.addView(titleBlock, matchWrap());
        lessonRoot.addView(spacer(10));
        playbackStatus = text("READY TO PLAY · Watch the notes unfold", 12, TEAL, true);
        lessonRoot.addView(playbackStatus);
        lessonRoot.addView(spacer(8));
        notesScroll = new ScrollView(this);
        notesScroll.setFillViewport(false);
        notesScroll.setBackground(roundDrawable(PANEL, 18));
        notesScroll.setPadding(dp(15), dp(15), dp(15), dp(15));
        notesText = text("", 16, TEXT, false);
        notesText.setLineSpacing(dp(5), 1.0f);
        notesText.setTextIsSelectable(true);
        notesScroll.addView(notesText);
        LinearLayout.LayoutParams notesParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1);
        notesParams.topMargin = dp(4); notesParams.bottomMargin = dp(12);
        lessonRoot.addView(notesScroll, notesParams);
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        playButton = primaryButton("▶  Play lesson");
        bottom.addView(playButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        View gap = new View(this); bottom.addView(gap, new LinearLayout.LayoutParams(dp(8), 1));
        Button restart = secondaryButton("Restart");
        bottom.addView(restart, new LinearLayout.LayoutParams(dp(100), dp(48)));
        lessonRoot.addView(bottom);
        lessonRoot.addView(spacer(8));
        Button back = secondaryButton("Back to classroom");
        lessonRoot.addView(back, matchWrap());
        back.setOnClickListener(v -> showDashboard());
        playButton.setOnClickListener(v -> togglePlayback());
        restart.setOnClickListener(v -> { handler.removeCallbacksAndMessages(null); playing = false; typedIndex = 0; diagramAlreadyShown = false; updateNotesText(); playbackStatus.setText("LESSON RESTARTED"); playButton.setText("▶  Play lesson"); });
        setContentView(lessonRoot);
    }

    private void togglePlayback() {
        if (!lessonScreenOpen) return;
        if (playing) {
            playing = false;
            handler.removeCallbacks(typingRunnable);
            playButton.setText("▶  Resume lesson");
            playbackStatus.setText("PAUSED · Your reading position is saved");
        } else {
            if (typedIndex >= lessonNotes.length()) {
                typedIndex = 0; diagramAlreadyShown = false;
            }
            playing = true;
            playButton.setText("Ⅱ  Pause lesson");
            playbackStatus.setText("PLAYING · Notes are typing in real time");
            scheduleTypingTick();
        }
    }

    private void scheduleTypingTick() {
        if (!playing || !lessonScreenOpen) return;
        typingRunnable = new Runnable() {
            @Override public void run() {
                if (!playing || !lessonScreenOpen) return;
                if (typedIndex >= lessonNotes.length()) {
                    playing = false;
                    playButton.setText("↻  Play again");
                    playbackStatus.setText("LESSON COMPLETE · Great work");
                    prefs.edit().putBoolean("lesson_complete_" + email, true).apply();
                    return;
                }
                typedIndex = Math.min(lessonNotes.length(), typedIndex + 2);
                updateNotesText();
                if (!diagramAlreadyShown && typedIndex >= cueIndex) {
                    diagramAlreadyShown = true;
                    savedScrollY = notesScroll.getScrollY();
                    resumeAfterDiagram = playing;
                    playing = false;
                    handler.removeCallbacks(this);
                    showDiagramOverlay();
                    return;
                }
                handler.postDelayed(this, 36);
            }
        };
        handler.post(typingRunnable);
    }

    private void updateNotesText() {
        if (notesText != null) {
            int end = Math.min(typedIndex, lessonNotes.length());
            notesText.setText(lessonNotes.substring(0, end));
            notesScroll.post(() -> notesScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    private void showDiagramOverlay() {
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(NAVY);
        LinearLayout content = pageColumn();
        content.setPadding(dp(18), dp(16), dp(18), dp(18));
        FrameLayout.LayoutParams full = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        overlay.addView(content, full);
        content.addView(topBar("LIVE DIAGRAM · 01"));
        content.addView(spacer(20));
        content.addView(text("Watch the field take shape.", 27, TEXT, true));
        content.addView(spacer(8));
        content.addView(text("MAGNETIC FIELD AROUND A STRAIGHT CURRENT-CARRYING WIRE", 12, TEAL, true));
        content.addView(spacer(14));
        FieldDiagramView diagram = new FieldDiagramView(this);
        LinearLayout.LayoutParams diagramParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1);
        content.addView(diagram, diagramParams);
        content.addView(spacer(14));
        LinearLayout explanation = cardColumn();
        explanation.setPadding(dp(16), dp(15), dp(16), dp(15));
        explanation.addView(text("LECTURER EXPLAINS", 11, PURPLE, true));
        explanation.addView(spacer(7));
        explanation.addView(text("Imagine the wire running through the centre. The magnetic field forms concentric circles around it. Point your right thumb in the direction of conventional current; your curled fingers show the field direction.", 15, TEXT, false));
        content.addView(explanation, matchWrap());
        content.addView(spacer(14));
        Button close = primaryButton("Close diagram · Return to notes");
        content.addView(close, matchWrap());
        close.setOnClickListener(v -> {
            diagram.stop();
            setContentView(lessonRoot);
            notesScroll.post(() -> notesScroll.scrollTo(0, savedScrollY));
            playbackStatus.setText("DEMONSTRATION COMPLETE · Continuing your notes");
            if (resumeAfterDiagram) {
                playing = true;
                playButton.setText("Ⅱ  Pause lesson");
                scheduleTypingTick();
            } else {
                playButton.setText("▶  Resume lesson");
            }
        });
        setContentView(overlay);
    }

    private void showAdminEditor() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = pageColumn(); page.setPadding(dp(18), dp(16), dp(18), dp(24)); scroll.addView(page);
        page.addView(topBar("LESSON EDITOR"));
        page.addView(spacer(16));
        page.addView(text("Prepare your lesson", 28, TEXT, true));
        page.addView(spacer(7));
        page.addView(text("Save as a local draft. The source notes remain editable; review all physics content before publishing.", 14, MUTED, false));
        page.addView(spacer(16));
        page.addView(text("LESSON TITLE", 12, TEAL, true)); page.addView(spacer(6));
        adminTitleInput = editField("Lesson title", false); adminTitleInput.setText(lessonTitle); page.addView(adminTitleInput, matchWrap());
        page.addView(spacer(14));
        page.addView(text("SOURCE NOTES / LECTURE SCRIPT", 12, TEAL, true)); page.addView(spacer(6));
        adminNotesInput = editField("Type or paste lesson notes…", false);
        adminNotesInput.setGravity(Gravity.TOP | Gravity.START);
        adminNotesInput.setMinLines(12); adminNotesInput.setMaxLines(24);
        adminNotesInput.setText(lessonNotes); page.addView(adminNotesInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)));
        page.addView(spacer(14));
        Button generate = primaryButton("Create editable lesson-plan draft"); page.addView(generate, matchWrap());
        generate.setOnClickListener(v -> {
            String src = adminNotesInput.getText().toString();
            String draft = "LESSON PLAN DRAFT\n\nObjective: Explain the key ideas in " + adminTitleInput.getText().toString().trim() + ".\n\nSequence:\n1. Introduce the concept and learning goal.\n2. Read and explain the source notes.\n3. Pause at the midpoint for a diagram demonstration.\n4. Review key terms and equations from the source.\n5. Ask a short understanding-check question.\n\nDiagram cue: Around the midpoint of the source notes.\n\nReview before publishing: verify every formula, diagram direction, definition and worked answer.\n\nSource notes length: " + src.length() + " characters.";
            EditText plan = editField("Editable lesson plan", false); plan.setGravity(Gravity.TOP | Gravity.START); plan.setMinLines(10); plan.setText(draft);
            new AlertDialog.Builder(this).setTitle("Review lesson plan").setView(plan).setPositiveButton("Save draft", (dialog, which) -> { prefs.edit().putString("lesson_plan_draft", plan.getText().toString()).apply(); Toast.makeText(this, "Lesson-plan draft saved on this device.", Toast.LENGTH_LONG).show(); }).setNegativeButton("Cancel", null).show();
        });
        page.addView(spacer(10));
        Button save = primaryButton("Save lesson changes"); page.addView(save, matchWrap());
        save.setOnClickListener(v -> {
            String title = adminTitleInput.getText().toString().trim();
            String notes = adminNotesInput.getText().toString().trim();
            if (title.isEmpty() || notes.length() < 20) { Toast.makeText(this, "Add a title and at least 20 characters of notes.", Toast.LENGTH_SHORT).show(); return; }
            lessonTitle = title; lessonNotes = notes;
            prefs.edit().putString("lesson_title", lessonTitle).putString("lesson_notes", lessonNotes).apply();
            Toast.makeText(this, "Lesson draft saved on this device.", Toast.LENGTH_SHORT).show(); showDashboard();
        });
        page.addView(spacer(10)); Button back = secondaryButton("Back"); page.addView(back, matchWrap()); back.setOnClickListener(v -> showDashboard());
        setContentView(scroll);
    }

    private void pickPdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        try { startActivityForResult(intent, PICK_PDF); }
        catch (Exception e) { Toast.makeText(this, "Could not open file picker on this device.", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PDF && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            String name = uri.getLastPathSegment();
            importedPdfName = name == null ? "PDF selected" : name;
            prefs.edit().putString("pdf_name", importedPdfName).putString("pdf_uri", uri.toString()).apply();
            Toast.makeText(this, "PDF selected. This prototype records the file reference but does not yet extract text or upload it.", Toast.LENGTH_LONG).show();
            showDashboard();
        }
    }

    private void showSubmissions() {
        new AlertDialog.Builder(this).setTitle("Student submissions")
                .setMessage("Submission storage is not connected in this prototype. The production version needs an authenticated backend, assignment records, file upload, and feedback permissions.")
                .setPositiveButton("OK", null).show();
    }

    private void showAssignment() {
        LinearLayout body = pageColumn(); body.setPadding(dp(20), dp(18), dp(20), dp(24));
        body.addView(topBar("ASSIGNMENT")); body.addView(spacer(18));
        body.addView(text("Field direction check", 28, TEXT, true)); body.addView(spacer(8));
        body.addView(text("Question: What happens to the direction of the magnetic field around a straight wire when the conventional current is reversed? Explain your reasoning.", 16, MUTED, false));
        body.addView(spacer(18));
        EditText answer = editField("Write your answer…", false); answer.setGravity(Gravity.TOP | Gravity.START); answer.setMinLines(6); body.addView(answer, matchWrap());
        body.addView(spacer(14)); Button submit = primaryButton("Save submission on this device"); body.addView(submit, matchWrap());
        submit.setOnClickListener(v -> { String a = answer.getText().toString().trim(); if (a.isEmpty()) { answer.setError("Write an answer first"); return; } prefs.edit().putString("assignment_answer_" + email, a).apply(); Toast.makeText(this, "Saved locally. It was not sent to a lecturer.", Toast.LENGTH_LONG).show(); showDashboard(); });
        body.addView(spacer(10)); Button back = secondaryButton("Back to classroom"); body.addView(back, matchWrap()); back.setOnClickListener(v -> showDashboard());
        setContentView(body);
    }

    // ---------- Reusable UI helpers ----------
    private LinearLayout pageColumn() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setBackgroundColor(NAVY); return l; }
    private LinearLayout cardColumn() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setBackground(roundDrawable(PANEL, 18)); return l; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private View spacer(int h) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h))); return v; }
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.START);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL)); t.setIncludeFontPadding(true); return t;
    }
    private TextView topBar(String label) {
        TextView t = text("◈  PHYSICS LAB                                      " + label, 10, MUTED, true); t.setGravity(Gravity.CENTER_VERTICAL); t.setMinHeight(dp(28)); return t;
    }
    private LinearLayout sectionHeading(String left, String right) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setOrientation(LinearLayout.HORIZONTAL);
        TextView a = text(left, 12, TEXT, true); row.addView(a, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(text(right, 10, TEAL, true)); return row;
    }
    private View statCard(String label, String number, String foot) {
        LinearLayout c = cardColumn(); c.setPadding(dp(14), dp(12), dp(12), dp(12));
        c.addView(text(label, 10, MUTED, true)); c.addView(spacer(4)); c.addView(text(number, 23, TEXT, true)); c.addView(text(foot, 10, MUTED, false)); return c;
    }
    private View infoRow(String num, String title, String subtitle, Runnable action) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(13), dp(14), dp(13), dp(14)); row.setBackground(roundDrawable(PANEL, 15));
        TextView n = text(num, 16, TEAL, true); n.setGravity(Gravity.CENTER); row.addView(n, new LinearLayout.LayoutParams(dp(36), dp(36)));
        LinearLayout words = new LinearLayout(this); words.setOrientation(LinearLayout.VERTICAL); words.setPadding(dp(10), 0, dp(4), 0); words.addView(text(title, 14, TEXT, true)); words.addView(spacer(4)); words.addView(text(subtitle, 12, MUTED, false));
        row.addView(words, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1)); row.addView(text("›", 25, TEAL, true)); row.setOnClickListener(v -> action.run()); return row;
    }
    private Button primaryButton(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(NAVY); b.setTextSize(14); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setBackground(roundDrawable(TEAL, 14)); b.setMinHeight(dp(48)); b.setPadding(dp(14), 0, dp(14), 0); return b;
    }
    private Button secondaryButton(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(TEXT); b.setTextSize(13); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setBackground(roundStrokeDrawable(PANEL, 14, Color.rgb(61, 78, 109))); b.setMinHeight(dp(46)); return b;
    }
    private EditText editField(String hint, boolean password) {
        EditText e = new EditText(this); e.setTextColor(TEXT); e.setHintTextColor(MUTED); e.setHint(hint); e.setTextSize(15); e.setSingleLine(false); e.setPadding(dp(14), dp(12), dp(14), dp(12));
        e.setBackground(roundStrokeDrawable(NAVY2, 12, Color.rgb(61, 78, 109))); e.setSelectAllOnFocus(false); return e;
    }
    private android.graphics.drawable.GradientDrawable roundDrawable(int color, int radius) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private android.graphics.drawable.GradientDrawable roundStrokeDrawable(int color, int radius, int stroke) {
        android.graphics.drawable.GradientDrawable d = roundDrawable(color, radius); d.setStroke(dp(1), stroke); return d;
    }

    @Override public void onBackPressed() {
        if (lessonScreenOpen) { showDashboard(); } else if (email.isEmpty()) { super.onBackPressed(); } else { showDashboard(); }
    }

    private final class FieldDiagramView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private long startedAt = System.currentTimeMillis();
        private boolean stopped = false;
        FieldDiagramView(Activity context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        void stop() { stopped = true; }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth(), h = getHeight();
            c.drawColor(NAVY2);
            float cx = w * 0.5f, cy = h * 0.47f;
            float maxR = Math.min(w * 0.41f, h * 0.39f);
            float phase = (System.currentTimeMillis() - startedAt) / 850f;
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f));
            for (int i = 1; i <= 4; i++) {
                float r = maxR * (i / 4f) * (0.96f + 0.04f * (float)Math.sin(phase + i));
                p.setColor(i % 2 == 0 ? PURPLE : TEAL); p.setAlpha(150 + i * 20); c.drawCircle(cx, cy, r, p);
                float ang = phase * 0.7f + i * 0.65f;
                float ax = cx + (float)Math.cos(ang) * r, ay = cy + (float)Math.sin(ang) * r;
                p.setStyle(Paint.Style.FILL); p.setColor(TEAL); c.drawCircle(ax, ay, dp(3), p); p.setStyle(Paint.Style.STROKE);
            }
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(255, 196, 117));
            c.drawRoundRect(new RectF(cx - dp(12), cy - maxR * 0.75f, cx + dp(12), cy + maxR * 0.75f), dp(10), dp(10), p);
            p.setColor(NAVY); c.drawCircle(cx, cy - maxR * 0.56f, dp(5), p);
            p.setColor(TEXT); p.setTextSize(dp(12)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextAlign(Paint.Align.CENTER);
            c.drawText("CURRENT-CARRYING WIRE", cx, cy + maxR + dp(28), p);
            p.setColor(MUTED); p.setTextSize(dp(11)); c.drawText("Concentric magnetic field lines", cx, cy + maxR + dp(48), p);
            if (!stopped) postInvalidateDelayed(70);
        }
    }
}
