# Prototype acceptance checklist

- [x] Native Android project structure and launcher activity.
- [x] Mandatory sign-in screen (demo-only validation).
- [x] Admin/student role-dependent dashboards.
- [x] Admin can edit and locally save lesson title and notes.
- [x] Admin can create and save an editable lesson-plan draft.
- [x] Admin can select a PDF file and retain its URI/name locally.
- [x] Student can view lesson and save an assignment answer locally.
- [x] Notes type progressively with playback controls.
- [x] A large animated diagram replaces the note view at a cue point.
- [x] Returning from the diagram restores the same lesson view and saved scroll offset; playback resumes when appropriate.
- [ ] Verified build to APK (blocked in current environment: Android SDK / Gradle absent and dependency hosts unreachable).
- [ ] Real account verification and server-side administrator authorization.
- [ ] Cloud persistence, secure PDF upload/extraction, student submissions and feedback.
- [ ] Device testing and release signing.
