# Physics Lab — Android prototype

This is the first Android implementation attempt for the Physics Lab app. It is a native Android project written in Java, using standard Android views and no third-party runtime libraries.

## Current prototype features

- Sign-in screen with email validation and a demo password field.
- Local demo role switch: `tamannakamrunnahar1235@gmail.com` opens the lecturer/admin dashboard; other emails open the student dashboard.
- Lecturer lesson editor for a lesson title and lecture notes, saved locally on the device.
- Editable lesson-plan draft generator based on the entered title and notes.
- PDF file picker; at this stage it remembers the chosen file reference/name only. It does **not** extract PDF text or upload the file.
- Progressive lecture-note playback.
- At the lesson's midpoint, a large animated magnetic-field diagram replaces the notes view. Closing it returns to the same lesson view and restores the saved scroll position, then playback resumes when it was playing before the diagram.
- Student assignment answer saved locally on the device.
- Basic student-submission placeholder screen.

## Important limitations — not production ready

The sign-in is **demo-only local validation**, not real authentication. Anyone who types the configured admin email can access the local admin prototype. Do not use real passwords. The production requirement — verified sign-in and an admin role enforced by a backend — has not been implemented, and must be added before real deployment.

The prototype does not yet include a Firebase/backend connection, cloud PDF storage or extraction, AI lesson-plan generation, synced course records, assignment uploads, lecturer feedback, or cross-device progress tracking. The plan draft is a generic editable starting point and must be reviewed for physics accuracy before use.

## Build an APK in Android Studio

This session does not have the Android SDK or Gradle installed, and the build environment cannot reach Google's download servers, so a compiled APK could not be produced here. The project is prepared for Android Studio and uses Android Gradle Plugin 8.7.3, compile SDK 35, and minimum Android API 23.

1. Install Android Studio on a computer and install Android SDK Platform 35 (or a compatible SDK from SDK Manager).
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the `PhysicsLabAndroid` folder.
4. Allow Gradle sync to download its build plugin and dependencies.
5. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will show the generated APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

The first debug APK should only be used for prototype testing. Before publishing, implement a real authentication provider (for example Firebase Authentication), server-side admin authorization for the single approved account, secure database/storage rules, and appropriate privacy/security handling.
